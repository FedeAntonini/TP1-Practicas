package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.interfaces.ListaOrdenada;
//TODO
public class Gestor {

	public void registrarTarea(Tarea tarea) {
		//TODO Completar
		if (tarea == null) {
			throw new IllegalArgumentException("Tarea nula");
		}
	}

	public void listarTareasPorDescripcion(Prioridad p) {
		//TODO Completar
	}

}
