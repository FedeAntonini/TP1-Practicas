package ar.edu.ar.ort.parcial2.clases;

public enum EstadoHabitacion {
    LIBRE,
    MANTENIMIENTO,
    RESERVADA
}
