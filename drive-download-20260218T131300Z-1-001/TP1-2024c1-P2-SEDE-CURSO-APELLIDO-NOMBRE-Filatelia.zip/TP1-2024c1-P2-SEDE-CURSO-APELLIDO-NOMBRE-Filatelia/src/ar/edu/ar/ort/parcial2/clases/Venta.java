package ar.edu.ar.ort.parcial2.clases;

public class Venta{
	
	private Sello sello;
	private int credencial;
	private String contacto;
	
	public Venta(Sello s, int cred, String c) {
		this.sello = s;
		this.credencial = cred; 
		this.contacto = c;
	}

	
	//COMPLETAR metodos 

	
	
}
