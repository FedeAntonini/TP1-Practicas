package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;
//TODO
public class ColaTareas extends ColaNodos<Tarea> {

}
