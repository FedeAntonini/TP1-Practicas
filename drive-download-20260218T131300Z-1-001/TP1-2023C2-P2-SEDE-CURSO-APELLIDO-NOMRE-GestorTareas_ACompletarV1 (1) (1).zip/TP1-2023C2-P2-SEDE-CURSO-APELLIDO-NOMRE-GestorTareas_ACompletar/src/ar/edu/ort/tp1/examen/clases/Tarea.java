package ar.edu.ort.tp1.examen.clases;
//TODO
public abstract class Tarea  {

	private static final String MSG_PRIORIDAD_INVALIDA = "Prioridad inv�lida";
	private static final String MSG_FECHA_INVALIDA = "Fecha de inicio inv�lida";
	private static final String MSG_DESCRIPCION_INVALIDA = "La descripcion no puede ser nula ni vac�a";
}
