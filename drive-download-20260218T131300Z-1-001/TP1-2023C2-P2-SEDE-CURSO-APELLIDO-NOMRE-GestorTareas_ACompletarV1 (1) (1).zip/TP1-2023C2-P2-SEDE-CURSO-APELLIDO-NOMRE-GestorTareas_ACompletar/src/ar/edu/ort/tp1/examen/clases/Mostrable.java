package ar.edu.ort.tp1.examen.clases;

public interface Mostrable {
	public void mostrar();
}
