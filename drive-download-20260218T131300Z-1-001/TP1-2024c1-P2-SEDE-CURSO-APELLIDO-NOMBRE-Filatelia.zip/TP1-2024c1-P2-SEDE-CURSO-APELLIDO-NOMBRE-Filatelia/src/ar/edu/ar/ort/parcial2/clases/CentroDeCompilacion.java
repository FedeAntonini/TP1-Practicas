package ar.edu.ar.ort.parcial2.clases;

public class CentroDeCompilacion{
	
	/*TODO
	Desarrollar constructores, estructuras, métodos 
	y excepciones pedidos
	en el enunciado*/

	
	public void realizarVentaSello(String pie, int cred, String contacto) {
	
			
	}
	
	
	
	private double calcularRecaudacion(double [][] ventas) {
		return 0;
		
	}
	
	private String verificarRecaudacion(double recaudacion) {
		return null;
	}
}
	

