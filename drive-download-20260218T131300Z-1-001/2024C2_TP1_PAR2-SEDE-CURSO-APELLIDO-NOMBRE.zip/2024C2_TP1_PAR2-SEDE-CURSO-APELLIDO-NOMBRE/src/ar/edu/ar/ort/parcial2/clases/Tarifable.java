package ar.edu.ar.ort.parcial2.clases;

public interface Tarifable {
    float calcularTarifa();
}
