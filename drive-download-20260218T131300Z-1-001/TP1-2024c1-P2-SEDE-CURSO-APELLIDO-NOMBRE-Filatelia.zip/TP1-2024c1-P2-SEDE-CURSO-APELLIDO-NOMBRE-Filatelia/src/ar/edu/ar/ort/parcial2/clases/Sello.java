package ar.edu.ar.ort.parcial2.clases;

public abstract class Sello{
	
	/*TODO
	Desarrollar constructores, estructuras, métodos
	y excepciones pedidos
	en el enunciado*/
	
	public Sello() {
		
		
		
	}
	
	
	
	
	
}
