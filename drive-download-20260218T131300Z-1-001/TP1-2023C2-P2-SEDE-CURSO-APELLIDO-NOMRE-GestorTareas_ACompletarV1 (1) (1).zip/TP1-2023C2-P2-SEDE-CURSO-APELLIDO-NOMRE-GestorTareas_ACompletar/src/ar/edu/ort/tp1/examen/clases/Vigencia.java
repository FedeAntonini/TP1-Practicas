package ar.edu.ort.tp1.examen.clases;

public interface Vigencia {

	public boolean estaVencido();
	public boolean estaVigente();
}
